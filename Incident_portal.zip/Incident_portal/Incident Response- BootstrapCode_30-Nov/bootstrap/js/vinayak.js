// Javascript Code


    
  
   //-------------Javascript for when select paloalto and block the "mohip"----------
                
document.getElementById("mohip").style.display = 'none';    // Once page load, this will hide the option


         // Global Variable for store the values for final validation check
         let userselectedfirewalls = '';      // Capture this value for identify the DB to POST the respective DB instance.
       //  console.log("Capture the Database", userselectedfirewalls);


let selectfirewall = () => {
   let selectedfirewalls = [];                                 // After Selected the options, it will store the selected values
   userselectedfirewalls = selectedfirewalls;                  // Global variable for capture the selected firewalls
   // console.log( document.getElementById('firewall_optionslist').options);
   for (let firewalloption of document.getElementById('firewall_optionslist').options) {
       // console.log(firewalloption);
       console.log(firewalloption.value);
   if (firewalloption.selected) {
       selectedfirewalls.push(firewalloption.value);
   }
   }
   console.log("Result in the array values", selectedfirewalls);

   selectedfirewalls.map((selectedfirewall)=>{                             // Iterate the Selected values stored in the array, then we match the selected values as paloalto
           console.log("MAP function output",selectedfirewall);

       if(selectedfirewall == "paloalto"){
           console.log("paloalto");
           document.getElementById("mohip").style.display = 'block';
       }else{
           console.log("other firewalls");
           // document.getElementById("mohip").remove();
           // document.getElementById("mohip").style.display = 'none';
           document.getElementById("mohip").innerHTML = '';                // This will replace the "mohip" to blank eventhough it was previously selected by paloalto
       }
       
})
}
   //-------------Javascript for when select paloalto and block the "mohip"----------


   // --------------------Javascript code on 02-Sept -------------------------

  // to hide, when render the Page by default
           // document.getElementById("singleip").style.display = 'none';
           // document.getElementById("iphide").style.display = 'none';
           document.getElementById("hashhide").style.display = 'none';
           document.getElementById("urlhide").style.display = 'none';
           document.getElementById("mohiphide").style.display = 'none';
           document.getElementById("domainhide").style.display = 'none';

           // To invoke the function once displayed the respective text box,based on the condition.

               // Global Variable for store the values for final validation check
              
               let capturetable = '' ;      // Capture this value for identify to POST the respective table.
               let finalpublicip = '';       //Capture the IP address
               let selectedsourceglobal = '';
               let publicipvalidationforprivateip = '';    //Capture the value for validation
               let hashvalue = '';                         //Capture the value for error validation check in else condition
               let urlvalue = '';                          //Capture the value for error validation check in else condition
               let domainvalue = '';                       //Capture the value for error validation check in else condition

           let IPvalidation = ()=>{
               alert("New Onchange IP validation is working");
               let IPinputvalue = document.getElementById("singleip").value;
               console.log("User Entered input", IPinputvalue);
               let readyforiterate = IPinputvalue.split(',');
               console.log("readyforiterate values", readyforiterate );

               let samplearray = [];
               finalpublicip = samplearray;                               // Store the public IP's values in to the Global variable
               readyforiterate.map((singleitem)=>{
               console.log("Single item values",singleitem);
               console.log("Check Data types for each ip",typeof(singleitem));
               singleitem = singleitem.replace(/\s+/g, "");                        // Validation for remove the white space. Removing the White spaces in the given input
               samplearray.push(singleitem);

               console.log("Array values inside Map",samplearray );

               // IP validation after Iterate the each IP

               if(singleitem){
                       console.log(singleitem);
                       //Valid Private IP address check
                       privateip = /\b(127\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|0?10\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?1[6-9]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?2[0-9]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?3[01]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|192\.168\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|169\.254\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|::1|[fF][cCdD][0-9a-fA-F]{2}(?:[:][0-9a-fA-F]{0,4}){0,7}|[fF][eE][89aAbB][0-9a-fA-F](?:[:][0-9a-fA-F]{0,4}){0,7})(?:\/([789]|1?[0-9]{2}))?\b/   // Private IP address
                       // Valid IP address check
                       validip = /^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;             // Public IP address pattern
                       if(validip.test(singleitem)) {  
                               console.log("Valid IP address")
                               if(!(privateip.test(singleitem))){
                                   console.log("Validated Public IP address in IF condition", singleitem);
                                   
                               }else{
                                   console.log("Validated Private IP address", singleitem);
                                   publicipvalidationforprivateip = singleitem;
                                   console.log("PublicIPValidation value", publicipvalidationforprivateip);

                               }
                       }else{
                           console.log("Enter a Valid IP address");

                       }
               
               }else{
                   console.log("Enter Valid Input");
               }
           // IP validation after Iterate the each IP


           });
           }


           let Hashvalidation = ()=>{
               alert("Onchange Hashvalidation is working");
               let IPinputvalue = document.getElementById("hashhide").value;
               console.log(IPinputvalue);
               finalpublicip = IPinputvalue;                                  // To keep the same variable name across the onchange function.
               
               // Copied Code
               let readyforiterate = IPinputvalue.split(',');
               console.log("readyforiterate values", readyforiterate );

               let samplearray = [];
               finalpublicip = samplearray;                               // Store the public IP's values in to the Global variable
               readyforiterate.map((singleitem)=>{
                   console.log("Single item values",singleitem);
                   console.log("Check Data types for each ip",typeof(singleitem));
                   singleitem = singleitem.replace(/\s+/g, "");                        // Validation for remove the white space. Removing the White spaces in the given input
                   samplearray.push(singleitem);

                   console.log("Array values inside Map",samplearray );

                   // IP validation after Iterate the each IP

                   if(singleitem){
                           console.log(singleitem);
                           // Valid SHA & MD5 Check 
                           let md5regex = /^[a-f0-9]{32}$/gi;
                           let sharegex = /^[a-f0-9]{64}$/gi;

                           if(md5regex.test(singleitem)){
                               console.log("Provided Input is MD5 :",singleitem );
                           }else if(sharegex.test(singleitem)){
                               console.log("Provided Input is SHA :", singleitem);
                           }else{
                               console.log("Validated, it's a wrong HASH ", singleitem);
                               hashvalue = singleitem;
                               console.log("HASH Validation value", hashvalue);            // Store the Value for Validation failure check
                           }
                   }else{
                       console.log("Enter Valid HASH Input");
                   }

               });
           }


           // Copied Code


           
           
           
           let Urlvalidation = () =>{
               alert("Onchange Url validation is working");
               let IPinputvalue = document.getElementById("urlhide").value;
               console.log(IPinputvalue);
               
               // Copied Code
               let readyforiterate = IPinputvalue.split(',');
               console.log("readyforiterate values", readyforiterate );

               let samplearray = [];
               finalpublicip = samplearray;                               // Store the public IP's values in to the Global variable
               readyforiterate.map((singleitem)=>{
                   console.log("Single item values",singleitem);
                   console.log("Check Data types for each ip",typeof(singleitem));
                   singleitem = singleitem.replace(/\s+/g, "");                        // Validation for remove the white space. Removing the White spaces in the given input
                   samplearray.push(singleitem);

                   console.log("Array values inside Map",samplearray );

                   // IP validation after Iterate the each IP

                   if(singleitem){
                           console.log(singleitem);
                           // Valid URL Check 

                           if(new URL(singleitem)){
                               console.log("Provided Input is Valid URL :",singleitem );
                           }else{
                               console.log("Validated, it's a wrong URL ", singleitem);
                               urlvalue = singleitem;
                               console.log("HASH Validation value", urlvalue);            // Store the Value for Validation failure check
                           }
                   }else{
                       console.log("Enter Valid HASH Input");
                   }

               });

               //Copied code
           }



           let mohipvalidation = ()=>{
               alert("Onchange MOHIP validation is working");
               let IPinputvalue = document.getElementById("mohiphide").value;
               console.log("User Entered input", IPinputvalue);
               let readyforiterate = IPinputvalue.split(',');
               console.log("readyforiterate values", readyforiterate );

               let samplearray = [];
               finalpublicip = samplearray;                               // Store the public IP's values in to the Global variable
               readyforiterate.map((singleitem)=>{
               console.log("Single item values",singleitem);
               console.log("Check Data types for each ip",typeof(singleitem));
               singleitem = singleitem.replace(/\s+/g, "");                        // Validation for remove the white space. Removing the White spaces in the given input
               samplearray.push(singleitem);

               console.log("Array values inside Map",samplearray );

               // Verify the Selected Firewall is Paloalto or not
               let verifyfirewall = '';
               userselectedfirewalls.map((userselectedfirewall)=>{
                   console.log(userselectedfirewall);
                   verifyfirewall = userselectedfirewall;
               });

               // IP validation after Iterate the each IP

               if(singleitem){
                       console.log(singleitem);
                       //Valid Private IP address check
                       privateip = /\b(127\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|0?10\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?1[6-9]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?2[0-9]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.0?3[01]\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|192\.168\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|169\.254\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|::1|[fF][cCdD][0-9a-fA-F]{2}(?:[:][0-9a-fA-F]{0,4}){0,7}|[fF][eE][89aAbB][0-9a-fA-F](?:[:][0-9a-fA-F]{0,4}){0,7})(?:\/([789]|1?[0-9]{2}))?\b/   // Private IP address
                       // Valid IP address check
                       validip = /^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;             
                       if(validip.test(singleitem)) {  
                               console.log("Valid IP address")
                               if((privateip.test(singleitem)) && (verifyfirewall == 'paloalto')){     // IP should be private & Firewall Selected to be 'paloalto'. in case choosen other firewalls, will fail this condition
                                   console.log("Validated Private IP address in IF condition", singleitem);
                                   
                               }else{
                                   console.log("Validated & found Public IP address", singleitem);
                                   publicipvalidationforprivateip = singleitem;
                                   console.log("PublicIPValidation value", publicipvalidationforprivateip);

                               }
                       }else{
                           console.log("Enter a Valid IP address");

                       }
               
               }else{
                   console.log("Enter Valid Input");
               }
           // IP validation after Iterate the each IP


           });
           }


           let domainvalidation = () =>{
               alert("Onchange Domain validation is working");
               let IPinputvalue = document.getElementById("domainhide").value;
               console.log(IPinputvalue);
               
               // Copied Code
               let readyforiterate = IPinputvalue.split(',');
               console.log("readyforiterate values", readyforiterate );

               let samplearray = [];
               finalpublicip = samplearray;                               // Store the public IP's values in to the Global variable
               readyforiterate.map((singleitem)=>{
                   console.log("Single item values",singleitem);
                   console.log("Check Data types for each ip",typeof(singleitem));
                   singleitem = singleitem.replace(/\s+/g, "");                        // Validation for remove the white space. Removing the White spaces in the given input
                   samplearray.push(singleitem);

                   console.log("Array values inside Map",samplearray );

                   // IP validation after Iterate the each IP

                   if(singleitem){
                           console.log(singleitem);
                           // Check Valid domain or not
                           let domainregex = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}$/i;

                           if(domainregex.test(singleitem)){
                               console.log("Provided Input is Valid Domain :",singleitem );
                           }else{
                               console.log("Validated, it's a wrong Domain ", singleitem);
                               domainvalue = singleitem;
                               console.log("Domain Validation value", domainvalue);            // Store the Value for Validation failure check
                           }
                   }else{
                       console.log("Enter Valid HASH Input");
                   }

               });

               //Copied code


               //copied code on 20-Nov
           }



           let onchangeipaddress = (t) =>{
               alert("Checking On chnage function");
               let optionValue = t.value;
               capturetable = optionValue;
               console.log("Global variable Data Cpature", optionValue);
               // let totalvalues = ["singleip", "hashhide","urlhide","mohiphide", "iphide", "domainhide" ];
               
               // console.log(totalvalues.length)
               if (optionValue == "ip") {
                       
                       //When the value condition is "IP" and it will display the "IP" text box as this "IP" text box has onchnage function to validate IP
                   // document.getElementById("iphide").style.display = 'block';
                   // document.getElementById("singleip").style.display = 'block';
                   document.getElementById("hashhide").style.display = 'none';
                   document.getElementById("urlhide").style.display = 'none';
                   document.getElementById("mohiphide").style.display = 'none';
                   document.getElementById("domainhide").style.display = 'none';
                   //Let capture the IP address field for POST the data.
                   capturetable = optionValue;
                   console.log("Capture the Table Data", capturetable);

               }else if (optionValue == "hash"){
                   // document.getElementById('singleiptext').innerHTML = "test1";
                   //When the value condition is "HASH" and it will display the "HASH" text box as this "HASH" text box has onchnage function to validate HASH
                   document.getElementById('hashhide').style.display = 'block'
                   document.getElementById("singleip").style.display = 'none';
                   document.getElementById('urlhide'). style.display = 'none'
                   document.getElementById('mohiphide'). style.display = 'none'
                   // document.getElementById("iphide").style.display = 'none';
                   document.getElementById("domainhide").style.display = 'none';
                  }
                  else if (optionValue == "url"){
                   // document.getElementById('singleiptext').innerHTML = "test1";
                   //When the value condition is "HASH" and it will display the "HASH" text box as this "HASH" text box has onchnage function to validate HASH
                   document.getElementById('urlhide'). style.display = 'block'
                   document.getElementById('hashhide').style.display = 'none'
                   document.getElementById("singleip").style.display = 'none';
                   document.getElementById('mohiphide'). style.display = 'none'
                   // document.getElementById("iphide").style.display = 'none';
                   document.getElementById("domainhide").style.display = 'none';
                  }
                  else if (optionValue == "domain"){
                   // document.getElementById('singleiptext').innerHTML = "test1";
                   //When the value condition is "HASH" and it will display the "HASH" text box as this "HASH" text box has onchnage function to validate HASH
                   document.getElementById("domainhide").style.display = 'block';
                   document.getElementById('hashhide').style.display = 'none'
                   document.getElementById("singleip").style.display = 'none';
                   document.getElementById('urlhide'). style.display = 'none'
                   document.getElementById('mohiphide'). style.display = 'none'
                   // document.getElementById("iphide").style.display = 'none';
                   
                  }
                  else if (optionValue == "mohip"){
                   // document.getElementById('singleiptext').innerHTML = "test1";
                   //When the value condition is "HASH" and it will display the "HASH" text box as this "HASH" text box has onchnage function to validate HASH
                   document.getElementById('mohiphide'). style.display = 'block'
                   document.getElementById('hashhide').style.display = 'none'
                   document.getElementById("singleip").style.display = 'none';
                   document.getElementById('urlhide'). style.display = 'none'
                   // document.getElementById("iphide").style.display = 'none';
                   document.getElementById("domainhide").style.display = 'none';
                  }
               }

               // Capture the Selected Source details

               let onchangesource = (u)=>{
                           selectedsource = u.value
                           console.log("Selected Source", selectedsource);
                           selectedsourceglobal = selectedsource;
               }

               

   // --------------------Javascript code on 02-Sept -------------------------


   // Hide the content. After Validation success need to display.
   document.getElementById('successalerttest').style.display = 'none';

   // Hide the content. After Validation Failure need to display.
   document.getElementById('failurealerttest').style.display = 'none';

   //---------JavaScript for Capture the User Entered Values ---------------
  
  
       let Getinputvalue = ()=>{

           console.log("Capture the Firewall types", userselectedfirewalls);                                   // Capture the selected firewalls
           console.log("Block Type testing the selected variables outside the function", capturetable);        // Capture the 2nd selected items
           console.log("Public IP captured after validation", finalpublicip );
           console.log("Type of Source", selectedsourceglobal);    // Capture the 3rd selected items
           console.log("Verify the publicip validation outside", publicipvalidationforprivateip);

           console.log("Capture the Hash Value", hashvalue);


           //Captured the User Input(IP, bulk ip) values in the "text" & "text area".
           let singleinputvalue = document.getElementById("singleip").value;      // Capture the "Block" user Input value in the input type "text"
           // let bulkinputvalue = document.getElementById("bulkip").value;   
           // let bulkinputvalue = document.getElementById("bulkip").value;            // Capture the "Block Bulk" user input values in the "textarea"
           let source_reference = document.getElementById("source_reference_no").value;            // Capture the "Block Bulk" user input values in the "textarea"
           let comments_value = document.getElementById("comment_value").value;            // Capture the "Block Bulk" user input values in the "textarea"
           
           console.log("source Reference User Input", source_reference);
           console.log(" User Comments value", comments_value);

       
           // alert(singleinputvalue + source_reference + comments_value );

  

           // Final Validation Before Send the data to Server

    
           let Validatetest = ()=>{
                   if(capturetable == 'select' || selectedsourceglobal == 'select' || userselectedfirewalls.includes('Select a Firewall')){
                       console.log("Raise a Validation Error. Choose the correct one");
                       return true;
                   }else if(!capturetable || !selectedsourceglobal || !userselectedfirewalls || !source_reference || publicipvalidationforprivateip || hashvalue || urlvalue || domainvalue){
                       console.log("Raise an Error. Missing User Input Values. ");
                       return true;
                   }
           }

          let validationresultfailure = Validatetest();
          console.log("Received the result from function",validationresultfailure);
   
           // Get a time for POST the data
           let gettime = () => {
               let currentdate = new Date();
               let datetime =  currentdate.getDate() + "/"+(currentdate.getMonth() + 1) 
               + "/" + currentdate.getFullYear() + "  " 
               + currentdate.getHours() + ":" 
               + currentdate.getMinutes() + ":" + currentdate.getSeconds();
               return datetime;
           }

           // Keep ready the Data in the Object

           class Finaldata{
               // constructor(firewall, blocktype, blockvalue,source, source_no, comments,date,entity, analyst_name)
               constructor(capturetable, finalpublicip, selectedsourceglobal, source_reference, comments_value ){

                   this.capturetable = capturetable;
                   if(capturetable == 'ip'){                   // When the IP table selected, it will assign it to IP
                       this.publicip = finalpublicip;
                   }else if(capturetable == 'hash'){         // When the HASH table selected, it will assign it to HASH           
                       this.hash = finalpublicip;
                      //Hash Validation. After that will create a object based on the hash type
                      let storemd5hasharray = [];
                      let storeshahasharray = [];

                       finalpublicip.map((singlehash) =>{
                           let md5regex = /^[a-f0-9]{32}$/gi;
                           let sharegex = /^[a-f0-9]{64}$/gi;
                           singlehash = singlehash.replace(/\s+/g, "");        // To remove the white spaces between provided input hash
                           if(md5regex.test(singlehash)){
                               storemd5hasharray.push(singlehash);
                               console.log("Provided Input is MD5 :",singlehash );
                               this.md5hash = storemd5hasharray;
                               this.hashtype = 'MD5';
                           }
                           if(sharegex.test(singlehash)){
                               storeshahasharray.push(singlehash);
                               console.log("Provided Input is SHA :", singlehash);
                               this.shahash = storeshahasharray;
                               this.hashtype = 'SHA';
                           }
                       });
                       
                       //Hash Validation. After that will create a object based on the hash type

                   }else if(capturetable == 'url'){         // When the HASH table selected, it will assign it to HASH           
                       this.url = finalpublicip;
                   }else if(capturetable == 'domain'){
                       this.domain = finalpublicip;
                   }else if(capturetable == 'mohip'){
                       this.mohip = finalpublicip;
                   }
                   this.selectedsourceglobal = selectedsourceglobal;
                   this.source_reference = source_reference;
                   this.comments_value = comments_value;
                   this.time = gettime();
               }
           }

          let accessfinaldata =  new Finaldata(capturetable, finalpublicip, selectedsourceglobal, source_reference, comments_value );
           // console.log(accessfinaldata.userselectedfirewalls);
           console.log(typeof(accessfinaldata));
           // console.log(accessfinaldata);
           
           // Check to add the property value. Before use MAP function, need to check whether user selected the firewall or not
           if(!validationresultfailure){
               userselectedfirewalls.map((userselectedfirewall)=>{
               console.log("Expected result");
               console.log(userselectedfirewall);
               // Spread Operator in ES6. it's already mapped the property and values. We are iterating the selected firewalls and add the property values for the iterated value
               let spreadtest = {
                   ...accessfinaldata,
                   firewall : userselectedfirewall,
               }



               // Segregate the Data for each firewall with table for POST to respective Endpoint

               if((spreadtest.firewall == 'paloalto') && (spreadtest.capturetable == 'ip')){
                   console.log("POST to Paloalto IP Endpoint")
                   console.log("Paloalto IP Data is Ready for POST", spreadtest);
               }
               if((spreadtest.firewall == 'paloalto') && (spreadtest.capturetable == 'hash')){
                   console.log("POST to Paloalto hash Endpoint")
               }
               if((spreadtest.firewall == 'paloalto') && (spreadtest.capturetable == 'domain')){
                   console.log("POST to Paloalto domain Endpoint")
               }
               if((spreadtest.firewall == 'paloalto') && (spreadtest.capturetable == 'url')){
                   console.log("POST to Paloalto URL Endpoint")
               }
               if((spreadtest.firewall == 'paloalto') && (spreadtest.capturetable == 'mohip')){
                   console.log("POST to Paloalto MOHIP Endpoint")
                   console.log("Paloalto MOHIP Data is Ready for POST", spreadtest);
               }
               if((spreadtest.firewall == 'fortigate') && (spreadtest.capturetable == 'ip')){
                   console.log("POST to Fortigate IP Endpoint")
                   console.log("Fortigate IP Data is Ready for POST", spreadtest);
               }
               if((spreadtest.firewall == 'cisco') && (spreadtest.capturetable == 'ip')){
                   console.log("POST to Cisco IP Endpoint")
                   console.log("Cisco IP Data is Ready for POST", spreadtest);
               }      
           




               // Segregate the Data for each firewall with table for POST to respective React API Endpoint URL.

               let successhidealert = () =>{
               alert =  document.getElementById('successalerttest')
               alert.style.display = 'block';
               setTimeout(()=>{
                           alert.style.display = 'none';
                       },3000);
                       }
               successhidealert();

               });


           }else{
               console.log("User Neither selected the firewall or Provided IP's mixed with Public/Private ")
               let warninghidealert = () =>{ 
                   alert = document.getElementById('failurealerttest');
                   alert.style.display = 'block';
                   // setTimeout(() =>{
                   //     alert.style.display = 'none';
                   //     }, 3000);
               }
               // When user continously click save btn, without fill the data/refresh the page, it will thrown an error. The error is can't display the Alert box so we have taken care the Error.
               try{
                   warninghidealert();
               }catch(e){
                   console.log("Couldn't run the function due to User double cliked without fill the Data/refresh the page")
                   console.log(e)
               }
               
           }
          


           // accessfinaldata.employee = 'Vinayak';
           //     a = 'VinayakLogafirewall';
           // let spreadtest = {
           //     ...accessfinaldata,
           //     firewall : a,
           // }
           // console.log(accessfinaldata);
           // console.log(spreadtest);



   }
   


//---------JavaScript for Capture the User Entered Values ---------------


