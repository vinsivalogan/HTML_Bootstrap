from rest_framework import serializers
from .models import Carsvinfilter


class CarsSerializer(serializers.ModelSerializer):

    class Meta:
        model = Carsvinfilter
        fields = ['id', 'car_brand', 'car_model',
                  'production_year', 'car_body', 'engine_type']
        # fields = "__all__"