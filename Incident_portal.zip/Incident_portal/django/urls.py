from django.urls import re_path as url,path
# from django.urls
from .views import  Carviewset, Carviewsetgetfilter, Carviewput, AllcarsView, AllcarsDelete      

from rest_framework.routers import DefaultRouter

urlpatterns = [

    path('carsview', AllcarsView.as_view()),
    path('carsdelete', AllcarsDelete.as_view()),
    path('create', Carviewset.as_view({
        'post': 'userpost',
    })),
    path("carfilter/<str:car_brand>", Carviewsetgetfilter.as_view({
        'get' : 'carget',
        'delete' : 'carlimitdelete',
    })),
    path("carupdate/<str:car_brand>", Carviewput.as_view({
        'put' : 'carput',
    })),

]