
from rest_framework.views import APIView
from rest_framework import viewsets,status
from rest_framework.response import Response
from .serializers import CarsSerializer
from rest_framework.throttling import UserRateThrottle
# from rest_framework.generics import CreateAPIView,ListAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView,UpdateAPIView,DestroyAPIView
from .models import Carsvinfilter as Cars
# from rest_framework.generics import GenericAPIView
from django.shortcuts import get_object_or_404

# from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters.rest_framework import DjangoFilterBackend

## GET Car filter brand and Delete
class Carviewsetgetfilter(viewsets.ViewSet):
    # serializer_class = CarsSerializer
    # lookup_field = "car_brand"
        # get request
    # def get(self, request, *args, **kwargs):
    def carget(self, request, car_brand=None):
        print("Capture Car brand", car_brand)
        # queryset = Cars.objects.all()
        queryset = Cars.objects.filter(car_brand__contains=car_brand)
        # user = get_object_or_404(queryset, car_brand=car_brand)
        print("Capture user input")
        print(queryset)
        print(type(queryset))
        serializer = CarsSerializer(queryset, many=True)
        return Response(serializer.data)

    def carlimitdelete(self, request, car_brand=None):
        queryset = Cars.objects.filter(car_brand__contains=car_brand)
        print(queryset)
        print("Check counting")
        print(len(queryset))
        count = len(queryset)
        if (count <= 5):
            # queryset.delete()
            result = {'success' : 'Accepted Deleted values less than 5'}
            print(result)
            return Response(result,status=status.HTTP_301_MOVED_PERMANENTLY)
        else:
            # queryset.delete()
            print("Deleted Entries are more than 5")
            result = {'Error' : 'Deleted Entries are more than 5. Try with less values'}
            return Response(result, status=status.HTTP_400_BAD_REQUEST)


# All Cars View

class AllcarsView(APIView):
    # serializer_class = CarsSerializer

    def get_queryset(self):
        cars = Cars.objects.all()
        return cars

    def get(self, request, *args, **kwargs):
        cars = self.get_queryset()
        serializer = CarsSerializer(cars, many=True)
        print("Executed to Display All Cars")
        return Response(serializer.data, status=status.HTTP_200_OK)


# All Cars Bulk Delete
class AllcarsDelete(APIView):
    # serializer_class = CarsSerializer

    def get_queryset(self):
        cars = Cars.objects.all()
        return cars

    def delete(self, request, *args, **Kwargs):
        carsreadytodelete = self.get_queryset()
        # carsreadytodelete.delete();
        result = {'success' : 'All Cars are Deleted'}
        print(result)
        return Response(result, status=status.HTTP_200_OK)




# All Cars POST

class Carviewset(viewsets.ViewSet):
    serializer_class = CarsSerializer

    # POST request
    def userpost(self, request, format=None):
        # def get_queryset(self):
        #     carbrand = self.kwargs['car_brand']
        #     print(carbrand);
        # serializer_class = CarsSerializer
        print("Print the browser Input")
        browserinput = (self.request.data)
        print(browserinput)
        # test1 = (self.request.data.get("car_brand"))
        print("Check the Data type received browser Input")
        print(type(browserinput))
        templist = []
        if isinstance(browserinput, list):                      # The user input receives as a List, it will execute this condition
            for elem in browserinput:
                print(elem)
                # test1 = (self.request.data.get("car_brand"))
                test1 = (elem.get("car_brand"))
                print(test1)
                templist.append(test1)
            print("Printing the temp list file")
            print(templist)                             # Itertate & Get a car brand and store it to the templist
            templistforduplicate = []
            for elem in templist:
                vinsample = Cars.objects.filter(car_brand = elem);          # Itertate templist and check the Query with DB whether car brand is already availble or not
                if(vinsample):                                              # It yields the results whatever matches values avaiable no of counts shows as Queryset
                    print("To test to print the duplicate value")
                    for elem in vinsample:
                        elem = CarsSerializer(elem)
                        # print(elem.__getitem__("car_brand"))
                        storedataduplicate = elem.data.get("car_brand")
                        templistforduplicate.append(storedataduplicate)
                        # print(storedataduplicate)

                    print("To test to print the duplicate value after Serializer")
                    print(type(templistforduplicate))
                    print(templistforduplicate)
                    # testcarbrand = vinsample.get("car_brand")
                    # print(testcarbrand)
                    # parsedata = CarsSerializer(vinsample)
                    # print(parsedata.data)
            if(templistforduplicate):
                templistremoveduplicate = list(set(templistforduplicate))                           # To remove duplicates brands which received it from DB result against our search
                print("Inside if condition templistforduplicate value", templistremoveduplicate)
                testresult = {}
                templistremoveduplicate = ' ,'.join(templistremoveduplicate)                        # Receives as list and convert it to string for the below line concatenation
                testresult['error'] = templistremoveduplicate + "  " +'Car brand already available. Try other Brand Name'
                result = {'error': 'Car brand already available. Try other Brand Name'}
                return Response(testresult,status=status.HTTP_400_BAD_REQUEST)
            else:
                print("finally Checking the count of User Input", browserinput)
                print(len(browserinput))
                browserinputcount = len(browserinput)
                if(browserinputcount >= 3):
                    result = {}
                    result['Error'] = str(browserinputcount) + " " +'Car brands values Entries posted. Try with less than 15 values '
                    # result = {'Error': 'Car brands values more than 3. Try with less than 3 entries '}
                    return Response(result, status=status.HTTP_400_BAD_REQUEST)
                else:
                    for elem in browserinput:
                        convertserializer = CarsSerializer(data=elem)           ## Here recieves the user input by FORM hence mentioned as "request.data"
                        convertserializer.is_valid(raise_exception=True)        # Here validating whether receives the user input is valid or not
                        convertserializer.save()                                # POST the FORM data to server
                        # return Response(convertserializer.data, status=status.HTTP_201_CREATED)
                result = {'Success': 'Car brands Updated'}
                return Response(result,status=status.HTTP_400_BAD_REQUEST)

        else:                                                           # The user input receives not as a List, it will execute this condition
            print("Received this browser input in the Else part",browserinput)
            ### Get the Car brand name from the POST Input Value ###
            test1 = (browserinput.get("car_brand"))
            print("Here checking the Car brand Name", test1)
            vinsample = Cars.objects.filter(car_brand=test1);  # Itertate templist and check the Query with DB whether car brand is already availble or not
            ### Check the Car brand name already exists on the Database table or not ###
            if (vinsample):  # It yields the results whatever matches values avaiable no of counts shows as Queryset
                print("Already Car brand avaialbe and not allow to write Duplicate entry", vinsample)
                return Response({'Failure': 'already available, Duplicate entry not allowed'}, status=status.HTTP_201_CREATED)
            else:
                convertserializer = CarsSerializer(data=browserinput)           ## Here recieves the user input by FORM hence mentioned as "request.data"
                convertserializer.is_valid(raise_exception=True)        # Here validating whether receives the user input is valid or not
                convertserializer.save()                                # POST the FORM data to server
            # return Response({'success' : 'Processed'}, status=status.HTTP_201_CREATED)
                return Response(convertserializer.data, status=status.HTTP_201_CREATED)


# Cars PUT

class Carviewput(viewsets.ViewSet):
    serializer_class = CarsSerializer

    #def carput(self, request, format=None):   # if we use the brand name to search for edit, it will be a logically incorrect becoz we put the new name to serach on the browser. The filter query will indenity the result hence using the ID. it means in React,
    # it will show all the Cars but when you clik to edit for single car, it should pass the "ID" number and edit the entries. Only one Car can edit in the browser & not same time to edit morethan one car
    # We can achieve it other way, in GUI when click the edit button, it will take the existing CAR brand name like /api/carupdate/nissan , after that will search the particular car, then again user can put the new values. In this case car brand name should be unique
    # def carput(self, request, pk=None):
    def carput(self, request, car_brand=None):
        browserinput = (self.request.data)
        print("Print the browser Input", browserinput)
        getcarbrand = browserinput.get("car_brand")
        print("Print the card brand", getcarbrand)
        fetchdata = Cars.objects.get(car_brand=car_brand)
        # fetchdata = Cars.objects.get(id=pk)
        # fetchdata = Cars.objects.get(many = true)
        print("Fetch the Car brand from Query",fetchdata )
        convertserializer = CarsSerializer(instance=fetchdata, data=browserinput)
        convertserializer.is_valid(raise_exception = True)
        convertserializer.save()
        return Response({'Success' : 'Updated the Car brand'},status=status.HTTP_202_ACCEPTED );







